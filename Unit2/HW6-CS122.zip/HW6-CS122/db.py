from sqlalchemy import create_engine, Column, Integer, String, Float, ForeignKey, Table
from sqlalchemy.orm import declarative_base, relationship, Session


#Task 1: Database Design and ORM Model 

engine = create_engine('sqlite:///books.db', echo=False)
Base = declarative_base()

#one to one relationship since no other tabke mentioned (one table for books and columns)

class Book(Base):
    __tablename__="books"

    id=Column(Integer, primary_key=True)
    title=Column(String, nullable=False)
    author=Column(String, nullable=False)
    year=Column(Integer)
    price=Column(Float)


# Create table
Base.metadata.create_all(engine) 












