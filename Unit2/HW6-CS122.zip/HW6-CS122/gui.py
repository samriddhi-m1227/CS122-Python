from db import engine, Base, Book
from sqlalchemy.orm import sessionmaker

Session = sessionmaker(bind=engine)
session = Session()

# Task 2: GUI using Tkinter

import tkinter as tk 
from tkinter import ttk

root = tk.Tk()
root.title("Main Window")

#Data Entry Form: 

book_id = tk.StringVar() #this is the primary key in the database 
book_title=tk.StringVar()
author=tk.StringVar()
year=tk.StringVar()
price=tk.StringVar()


ttk.Label(root, text="Book ID:").pack() #required field 
book_id_entry = ttk.Entry(root, textvariable=book_id, width=30)
book_id_entry.pack(padx=10, pady=5)

ttk.Label(root, text="Book Title:").pack()
ttk.Entry(root, textvariable=book_title, width=30).pack(padx=10, pady=5)

ttk.Label(root, text="Author:").pack()
ttk.Entry(root, textvariable=author, width=30).pack(padx=10, pady=5)

ttk.Label(root, text="Year:").pack()
ttk.Entry(root, textvariable=year, width=30).pack(padx=10, pady=5)

ttk.Label(root, text="Price:").pack()
ttk.Entry(root, textvariable=price, width=30).pack(padx=10, pady=5)



# Operations:

#add book

def add_book():
     if not book_id.get(): #if it is not full then give warning 
        print("Book ID is required.")
        return

     try:
        book_id_int = int(book_id.get())
     except ValueError:
        print("Book ID must be an integer.")
        return
    
     existing = session.query(Book).filter_by(id=book_id_int).first()
     if existing:
        print("Book already exists.")
        return

     # making sure all feilds are full after ID is defenitly filled 
     if not (book_title.get() and author.get() and year.get() and price.get()):
        print("All fields (title, author, year, price) must be filled.")
        return

     try:
        new_book = Book(
            id=book_id_int,
            title=book_title.get(),
            author=author.get(),
            year=int(year.get()),
            price=float(price.get())
        )
     except ValueError:
        print("Invalid input. Year must be int, Price must be float.")
        return

     session.add(new_book)
     session.commit()
     print("Book added successfully.")


# Button and Enter Key Binding
ttk.Button(root, text='Add Book', command=add_book).pack(pady=10)
root.bind("<Return>", lambda e: add_book()) #binding on window for smoother feel 


#button to display current list of books in db in a widget using ttk.Treeview
columns=("id", "title", "author", "year", "price")
tree= ttk.Treeview(root, columns=columns, show='headings')

for col in columns:
    tree.heading(col, text=col.title())  # sets column label
    tree.column(col, width=100)          # sets column width

tree.pack(pady=10)


def display_books():
    for row in tree.get_children():
        tree.delete(row)

    books = session.query(Book).all()

    for book in books:
        tree.insert("", "end", values=(
            book.id,
            book.title,
            book.author,
            book.year,
            book.price
        ))


ttk.Button(root, text="Display Books", command=display_books).pack()

#updating book

def update_book():
    if not book_id.get():
        print("Book ID is required.")
        return

    try:
        book_id_int = int(book_id.get())
    except ValueError:
        print("Book ID must be an integer.")
        return

    # Check if book exists
    book = session.query(Book).filter_by(id=book_id_int).first()
    if not book:
        print("Book not found. Cannot update.")
        return

    try:
        book.title = book_title.get()
        book.author = author.get()
        book.year = int(year.get())
        book.price = float(price.get())
    except ValueError:
        print("Invalid input. Year must be int, Price must be float.")
        return

    session.commit()
    print("Book updated successfully.")

    display_books()  # Refresh Treeview



ttk.Button(root, text="Update Book", command=update_book).pack(pady=10)


#Delete book

def delete_book():
    if not book_id.get():
        print("Book ID is required.")
        return

    try:
        book_id_int = int(book_id.get())
    except ValueError:
        print("Book ID must be an integer.")
        return

    book = session.query(Book).filter_by(id=book_id_int).first()
    if not book:
        print("Book not found. Cannot delete.")
        return

    session.delete(book)
    session.commit()
    print("Book deleted successfully.")

    display_books()  # Refresh Treeview
    

ttk.Button(root, text='Delete Book', command=delete_book).pack()


root.mainloop()