import pandas as pd

data=pd.read_csv('accident_100k.csv')
print(data.shape) #has 100,000 rows and 21 columns 
data.isna().sum()

mystates=['CA', 'FL', 'TX', 'NY'] #only keeping data rows of these selected states 
data=data[data['State'].isin(mystates)]

#Since there is only 1 missing for 'Street' and 'City', we can drop those rows. 
data=data.dropna(subset=['Street', 'City'])

# dropped wind chill since we wont be using it in our analysis 
data=data.drop(columns=['Wind_Chill(F)'])

#leaving the rest as if for now. If there is a need for specifc columns later on in the analysis, I will handle missing values then.


"""
Task 1: Time Series Analysis per State
- Plotting Task:
Create a single plot, with multiple lines (one for each state), showing the number of accidents per day for each of the four states.
"""
# I will use 'Weather_Timestamp' for this but there are some missing values
# only 1.4 percent of this column has missing values so I drop the missing ones entirely 
data=data.dropna(subset=['Weather_Timestamp'])
data['Weather_Timestamp']=pd.to_datetime(data['Weather_Timestamp'])

#now I must use date from each timestamp and graph the number of accidents against date for each state 
data['Date']=data['Weather_Timestamp'].dt.date

#Group by Date and State to get the count of accidents in this group
grouped=data.groupby(['Date', 'State']).size() #size() gets the count of rows of each group

#Time to plot 
import matplotlib.pyplot as plt

grouped=grouped.reset_index(name='Accident_Count') #makes the last column accident count so its a dataframe
pivot_data=grouped.pivot(index='Date', columns='State', values='Accident_Count')#makes it easy to plot 
#index is like x , values is y, columns is 'by'

#There are very minor missing values we can drop
pivot_data.isna().sum()
pivot_data=pivot_data.dropna()

pivot_data.plot(figsize=(14, 6), linewidth=2)

plt.title('Number of Accidents per Day by State')
plt.xlabel('Date')
plt.ylabel('Number of Accidents')
plt.legend(title='State')
plt.grid(True)
plt.tight_layout()
plt.show()
plt.close()



"""
Task 2: Heatmap of Accident Density by Day-of-the-Week and State
- Plotting Task: Construct a single heatmap showing density (do not use number of accidents directly, you must use  density, i.e. proportion of accidents in state) of accidents by state along the x-axis and day of week along the y-axis.  
"""

# extract day of week from the weather timestamp
data['DayofWeek']=data['Weather_Timestamp'].dt.day_name()

#get the state totals for the density 
state_total=data['State'].value_counts()

#group by the day in the week and state, get the freqnecy div by total for density 
grouped2=data.groupby(['DayofWeek', 'State']).size()/state_total

grouped2=grouped2.reset_index(name='Accident_Density')
pivot_data2=grouped2.pivot(index='DayofWeek', columns='State', values='Accident_Density')#makes it easy to plot 

#plot this with Heatmap:
import seaborn as sns

#ordering days of the week 
days_ordered = ['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday', 'Sunday']
pivot_data2 = pivot_data2.reindex(days_ordered)

plt.figure(figsize=(10, 6))
sns.heatmap(pivot_data2, annot=True, cmap='Blues', fmt='.2f', linewidths=0.5)

plt.title('Accident Density by Day of the Week and State')
plt.xlabel('State')
plt.ylabel('Day of the Week')

plt.tight_layout()
plt.show()
plt.close()



"""
### Task 3: Box Plot Analysis for Accident Severity by Weather Category
- Plotting Task: Create 4 box plots (one for each selected state) to compare accident severity in each state across the following weather conditions: Fair, Mostly Cloudy, Cloudy, Clear.
"""

#Since we need State, Weather condition and Severity, it is good to check for missing values in those rows 
data.isna().sum()

#Severity had 0 --> all good

#Weather_Condition has 139 missing out of 35611.
#This is less 0.39 percent of the data missing
#which is very insignificant since its less than 0.5%
#Therefore I will drop these missing rows 

data=data.dropna(subset=['Weather_Condition'])

weather_conditions=['Fair', 'Mostly Cloudy', 'Cloudy', 'Clear'] #filter data for only these weather conditions
filtered_data=data[data['Weather_Condition'].isin(weather_conditions)]
filtered_data['Weather_Condition'].value_counts()


states = ['CA', 'FL', 'NY', 'TX']

# Loop through each state and plot separately
for state in states:
    plt.figure(figsize=(6, 4))
    
    # Filter data for this state
    state_data = filtered_data[filtered_data['State'] == state]

    sns.boxplot(x='Weather_Condition', y='Severity', data=state_data)
    plt.title(f'Accident Severity by Weather Condition in {state}')
    plt.xlabel('Weather Condition')
    plt.ylabel('Accident Severity')
    plt.xticks(rotation=45)
    

    # Show the plot
    plt.tight_layout()
    plt.show()
    plt.close()



"""
Task 4: Histogram of Accident Severity
- Plotting Task: Plot histograms (one for each state) to display the frequency distribution of accident severity scores.
"""
states = ['CA', 'FL', 'NY', 'TX']

# Loop through each state and plot separately
for state in states:
    plt.figure(figsize=(6, 4))
    
    # Filter data for this state
    state_data = data[data['State'] == state]

    sns.histplot(x='Severity', data=state_data, bins=4, discrete=True)
    plt.title(f'Frequency by Accident Severity in {state}')
    plt.xlabel('Severity Score')
    plt.ylabel('Frequency')
    plt.xticks([1, 2, 3, 4])  # Ensure all severity scores show
    plt.tight_layout()
    plt.show()
    plt.close()



"""
Task 5: Open-Ended Exploration

My Choice: During which hours of the day do most accidents occur in California on Tuesdays?

- Plot Type: A bar plot 
"""
ca_data=data[data['State']=='CA'] #only california data

#california tuesday data
ca_tuesday_data=ca_data[ca_data['DayofWeek']=='Tuesday'].copy() #made a .copy() to avoid warning message
ca_tuesday_data['Hour']=ca_tuesday_data['Weather_Timestamp'].dt.hour #get the hour 

accidents_by_hour=ca_tuesday_data['Hour'].value_counts().sort_index() #get the count for accidents per hour on tuesday in CA

#plot:
plt.figure(figsize=(10, 6))
accidents_by_hour.plot(kind='bar', color='skyblue')

plt.title('Accident Frequency by Hour in California on Tuesdays')
plt.xlabel('Hour of the Day')
plt.ylabel('Number of Accidents')
plt.xticks(rotation=0)
plt.tight_layout()

plt.show()
plt.close()