# Social Media Data Analysis
### CS122-HW4- Samriddhi Matharu

## Overview
This project analyzes social media post data to extract insights through data wrangling, sentiment analysis, time-series visualization, and correlation analysis.

## Pre-Assignement Findings
- data.info() showed me there were oriinally 6 columns and 500 rows in the data 
- Note: The first 400 hundred do not have any mentions "@" , the last 100 do.
- data.isna().sum() showed me there were 5,10,and 6 missing values in post_content, likes and shares respectively 


## Assignement Tasks and Findings

### **Part A: Data Wrangling**
- **Handling Missing Values:** 
  - Missing values in `likes` were filled with the median.
  - Missing values in `shares` were filled with the mean.
  - Missing `post_content` was replaced with `"no text"`.
- **Data Cleaning:** 
  - Cleaned posts by removing hashtags, mentions, emojis, and URLs.
  - Extracted hashtag words for further analysis.
- **Datetime Processing:**
  - Converted `post_date` into a proper `datetime` format.

### **Part B: Data Analysis**

#### **1 Top Users by Engagement**
- The **top three users** with the highest total engagement (likes + shares) are user 1082, 1037 and 1024
- These users have significantly more interactions, indicating high influence.

#### **2 Most Popular Hashtags**
- Extracted and counted hashtags from all posts.
- **Top 5 most used hashtags** were identified.
- Certain hashtags trend more, such as:
outdoorfun:    27
foodie:       26
cozytime:      20
goodtimes:      20
adventure:     20

This suggests popular discussion circuating these topics.

###  **Part C: Sentiment Analysis**
#### **1️ Sentiment Classification**
- Performed sentiment analysis on cleaned post content. (positive, negative, neutral)
- Assigned a sentiment category and a numeric score to each post (in order to calculate avg).

#### **2️ Sentiment Distribution**
- **Findings:**
- The majority of posts in the data had **positive sentiment** (334 posts).
- followed by neutral( 97) and finally negative(69)
- **User-based Sentiment Analysis:** 
  - Calculated the **average sentiment score** for each user.

### **Part D: Unit Testing**
- Unit tests were implemented in a separate file (hw_test.py)to validate cleaned post content, sentiment classification, and engagement for users.

###  **Part E: Analysis & Visualization**
#### **1️ Word Cloud of Common Hashtags**
- A **WordCloud** was generated from the most frequently used hashtags.
- **Insight:** The largest words in the word cloud include 'outdoorfun', 'foodie', 'cozytime', 'workout', 'nature' and more which is consistent with our calculated Top 5 most popular hashtags

#### **2️ Time Series Analysis of Posts Per Month**
- A **line plot** was created to show the number of posts per month.
- **Key Findings:** 
- Posting activity fluctuates, with certain months seeing **higher engagement**.
- This could be due to seasonal trends or specific events. there are peaks in (for 2023) January, March, May, July, August, October, December. And january 2024.
- There is no linear like trend is it very rigid throghout the months. 


#### **3️ Correlation Between Likes and Shares**
- **Scatter plot** visualizing the relationship between likes and shares.
- **Correlation coefficient:** `0.95089` 
- **Conclusion:** 
- This is a strong positive correlation between likes and shares which means posts with high likes also seem to have higher shares 
  - Suggests that **popular content spreads quickly** through sharing.

---

## File Structure:
- cs122-HW4
    - data
        - social_media_posts.csv (Original dataset)
    - main.py (Main script performing analysis) 
    - functions.py (Helper functions for cleaning and sentiment analysis, also used for unit tests) 
    - test_hw.py (Unit tests)
    - README.md (This file)
    - wordcloud.png (Word cloud visualization of hashtags)
    - posts_per_month_lineplot.png (Line plot of posts per month)
    - likes_vs_shares_scatter.png (Scatter plot of likes vs. shares)
