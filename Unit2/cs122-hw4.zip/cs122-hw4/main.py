# main.py

import pandas as pd
from wordcloud import WordCloud
import matplotlib.pyplot as plt
from functions import clean_post_content, extract_hashtags, perform_sentiment_analysis

# Load data
data = pd.read_csv('data/social_media_posts.csv') 

"""Belongs to Part A (Data Wrangling) : Task  1, 2 and 3 """

# Handling missing values in likes, shares, post_content
data_filled = data.fillna({'likes': data['likes'].median(), 'shares': data['shares'].mean(), 'post_content': 'no text'})

# Apply cleaning functions for hashtags, mentions, emojis and urls.
data_filled['cleaned_post_content'] = data_filled['post_content'].apply(clean_post_content)

#extracting the hashatg words into another column 
data_filled['hashtags'] = data_filled['post_content'].apply(extract_hashtags)

# Reassigning to 'data' fto keep it simple 
data = data_filled

# Convert post_date to datetime
data['post_date'] = pd.to_datetime(data['post_date'])


""" Belongs to Part B (Data Analysis): Task 1 and 2"""

# Task 1: Calculate top users by total engagement (likes+shares)
user_engagement = data.groupby('user_id')[['likes', 'shares']].mean()
user_engagement['total_engagement'] = user_engagement['likes'] + user_engagement['shares']
top_three_users = user_engagement['total_engagement'].sort_values(ascending=False).head(3)
print("Top 3 users with highest total engagement:", top_three_users)

# Task 2: Extract and count the most frequent topics from hashtags
all_hashtags = data['hashtags'].str.split().explode()
popular_topics = all_hashtags.value_counts()
print("Top 5 most popular hashtag topics:", popular_topics.head(5))


"""Belongs to Part C (Sentiment Analysis):  Task 1 and 2 """

# Task 1: Perform sentiment analysis on the cleaned post content
data['sentiment'], data['sentiment_numeric'] = zip(*data['cleaned_post_content'].apply(perform_sentiment_analysis))

# Task 2: Sentiment distribution
sentiment_distribution = data['sentiment'].value_counts()
print("Sentiment Distribution:", sentiment_distribution)

#  Average sentiment score for each user
avg_user_sentiment = data.groupby('user_id')['sentiment_numeric'].mean()
print("Average sentiment score for each user:", avg_user_sentiment)


""" Part D of HW (unit tesing) is in seperate file"""


"""Part E (Analysis and visualization): Task 1,2, and 3 """

#Task 1: wordcloud of common hashtags, show and store plot 
common_hashtags=popular_topics #common_hashtags is popular_topics which is the list of all cleaned hashatgs and thier counts 
wc=WordCloud(width=800, height=400).generate_from_frequencies(common_hashtags)
plt.figure(figsize=(10, 5))
plt.imshow(wc)
plt.axis('off')
wc.to_file('wordcloud.png') #store the plot in png file 
plt.clf()
plt.close()

#Task 2: time series (line plot) for number of posts per month. show and store plot 
posts_per_month=data.groupby(data['post_date'].dt.to_period('M')).size()
posts_per_month.plot(kind='line',linestyle='-', figsize=(10, 6), title='Number of Posts per Month')
plt.xlabel('Month')
plt.ylabel('Number of Posts')
plt.savefig('posts_per_month_lineplot.png') #store the line plot in png file 
plt.show()
plt.clf()
plt.close()

#Task 3: Correlation between likes and shares for each post. Make a scatterplot, show and store it 
correlation = data['likes'].corr(data['shares'])
#scatter plot using pandas 
data.plot(kind='scatter', x='likes', y='shares', alpha=0.5, color='blue', figsize=(8, 6))
plt.title('Scatter Plot of Likes vs Shares')
plt.xlabel('Likes')
plt.ylabel('Shares')
plt.savefig('likes_vs_shares_scatter.png') #store scatter plot as png 
plt.show()
plt.clf()
plt.close()

