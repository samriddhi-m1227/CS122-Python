# functions.py is for all fucntions and for unittests
import re
from textblob import TextBlob

def clean_post_content(post_content):
    """Clean post content by removing hashtags, mentions, emojis, and URLs."""
    if not isinstance(post_content, str):
        post_content = str(post_content)  # Convert non-string values to string

    hashtag_pattern = r"#(\w+[-_]*\w*)"  
    mention_pattern = r"@(\w+)" 
    emoji_pattern = r"[^\w\s,]" 
    url_pattern=r"http\S+"  #if there is any
    
    post_content = re.sub(hashtag_pattern, lambda x: x.group()[1:], post_content)
    post_content = re.sub(mention_pattern, lambda x: x.group()[1:], post_content)
    post_content = re.sub(emoji_pattern, '', post_content)
    post_content = re.sub(url_pattern, "", post_content)
    
    return post_content

def extract_hashtags(post_content):
    """Extract hashtags from the post content."""
    hashtag_pattern = r"#(\w+[-_]*\w*)"
    hashtag_words = re.findall(hashtag_pattern, post_content)
    return ' '.join(hashtag_words)

def perform_sentiment_analysis(post_content):
    """Perform sentiment analysis and return sentiment label and polarity."""
    blob = TextBlob(post_content)
    polarity = blob.sentiment.polarity
    if polarity < 0:
        return 'negative', polarity
    elif polarity > 0:
        return 'positive', polarity
    else:
        return 'neutral', polarity

def calculate_average_engagement(likes, shares):
    """Calculate the average engagement based on likes and shares."""
    return (likes + shares) / 2
