import unittest
from functions import clean_post_content, extract_hashtags, perform_sentiment_analysis, calculate_average_engagement

class TestFunctions(unittest.TestCase):

    # Test for cleaning post content (removing hashtags, mentions, emojis, and URLs)
    def test_clean_post_content(self):
        post_content = "Check out this link http://blahblah.com #amazing @user :)"
        cleaned_content = clean_post_content(post_content)
        expected_content = "Check out this link  amazing user " 
        self.assertEqual(cleaned_content, expected_content)

    # Test for extracting hashtags from the post content
    def test_extract_hashtags(self):
        post_content = "This is a post with #hashtag1 and #hashtag2."
        hashtags = extract_hashtags(post_content)
        self.assertEqual(hashtags, "hashtag1 hashtag2")  # should return without the '#' symbol

    # Test for sentiment analysis of a positive post
    def test_sentiment_analysis_positive(self):
        post_content = "I love this product! It's amazing."
        sentiment, polarity = perform_sentiment_analysis(post_content)
        self.assertEqual(sentiment, 'positive')  # Sentiment should be 'positive'
        self.assertGreater(polarity, 0)  # Polarity should be positive (more than 0)

    # Test for sentiment analysis of a neutral post
    def test_sentiment_analysis_neutral(self):
        post_content = "I have no opinion on this "
        sentiment, polarity = perform_sentiment_analysis(post_content)
        self.assertEqual(sentiment, 'neutral')  # Sentiment should be 'neutral'
        self.assertEqual(polarity, 0)  # Polarity should EQUAL zero for neutral sentiment

    # Test for sentiment analysis of a negative post
    def test_sentiment_analysis_negative(self):
        post_content = "This product is terrible. I hate it."
        sentiment, polarity = perform_sentiment_analysis(post_content)
        self.assertEqual(sentiment, 'negative')  # Sentiment should be 'negative'
        self.assertLess(polarity, 0)  # Polarity should be negative (less than 0)

    # Test for calculating average engagement (likes + shares)
    def test_calculate_average_engagement(self):
        likes = 10
        shares = 20
        avg_engagement = calculate_average_engagement(likes, shares)
        self.assertEqual(avg_engagement, 15)  #should equal 15

if __name__ == '__main__':
    unittest.main()

